/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l2;

/**
 *
 * @author oven1
 */
import java.util.Scanner;
public class L2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        String str = "";
        System.out.print("Задание а:");
        System.out.println();
        System.out.println("Ввести свой массив? [Y]/[N]");
        String check = in.nextLine();
        switch(check)
        {
            case "Y":
                System.out.println("Введите массив");
                str = in.nextLine();
                IntArr obj = new IntArr(str);
                obj.outArr();
                break;
            case "N":
                IntArr obj1 = new IntArr();
                obj1.outArr();
                break;
            default: 
                System.out.print("Не корректная запись");
        }
        System.out.println();
        System.out.print("Задание b: ");
        System.out.println("\nВвести свой текст? [Y]/[N]");
        check = in.nextLine();
        switch(check)
        {
            case "Y":
                System.out.println("Введите текст для проверки:");
                str = in.nextLine();
                MyStr obj2 = new MyStr(str);
                obj2.SpaceCount();
                break;
            case "N":
                MyStr obj3 = new MyStr();
                obj3.SpaceCount();
                break;
            default: 
                System.out.print("Не корректная запись");
        }
        System.out.println();
        System.out.print("Задание c: ");
        System.out.println("\nВвести свой текст? [Y]/[N]");
        check = in.nextLine();
        switch(check)
        {
            case "Y":
                System.out.println("Ведите текст для проверки:");
                str = in.nextLine();
                MyStr obj2 = new MyStr(str);
                obj2.Slova();
                break;
            case "N":
                MyStr obj3 = new MyStr();
                obj3.Slova();
                break;
            default: 
                System.out.println("Не корректня запись");
        }
        System.out.println();
    }
    
}
