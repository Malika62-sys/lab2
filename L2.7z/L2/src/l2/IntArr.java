/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l2;

/**
 *
 * @author oven1
 */
public class IntArr {
    private int[] arr;
    public IntArr(String str){
        String separators = "[ ,;.:]+";
    	String[] words = str.split(separators);
        int i;
        arr = new int[words.length];
        for(i = 0; i < words.length;i++)
        {
            arr[i] = Integer.parseInt(words[i]);
        }   
    }
    public IntArr(){
        arr = new int[] {1, 5, 78, -10, -5, 0, 15, -42, -13, 14};
    }
    public void outArr() {
        int i;
	for ( i = 0; i < arr.length; i++)
	{
            if(arr[i]>0)
            {
		System.out.print("     " + arr[i]);
            }
            else
            {
		System.out.print(arr[i]);
            }
        }
    }
}
