/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l2;

/**
 *
 * @author oven1
 */

public class MyStr {
    private String text1;
    public MyStr()
    {
        text1 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sed elementum ex. Nunc eget orci sed nulla fringilla vulputate. Ut.";
        System.out.println(text1);
    }
    public MyStr(String str) {
        text1 = str; 
    }
    public void SpaceCount(){
        int spaceCount = 0;
        for (char c : text1.toCharArray())
        {
            if (c == ' ')
            {
                spaceCount++;
            }
        }
        System.out.print("Кличество пробелов в тексте = " + spaceCount);
    }
    public void Slova(){
        String separators = "[ ,;.:]+";
    	String[] words = text1.split(separators);
    	System.out.println("Нечётные слова");
        int i;
    	for ( i = 0; i < words.length; i++)
    	{
            if ( i % 2 == 0)
            {
                System.out.print(words[i] + " ");
            }
        }
        System.out.println("\nЧётные слова");
        for ( i = 0; i < words.length; i++)
        {
            if ( i % 2 == 1)
            {
                System.out.print(words[i] + " ");
            }
        }
    }
}
